length = "6"
width = "7"
print "area = (6 * 7)"
