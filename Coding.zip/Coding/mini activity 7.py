# Movie Ticket Eligibility Program

# Step 1: Ask the user for their age
"age" == "16"

# Step 2: Ask if they have parental permission
parental_permission = "no"

# Step 3: Check if the user can watch the movie
if "age" == ">18" or {"parental_permission"} == "yes" :
    print("You can watch the movie.")
else:

 print("You cannot watch the movie.")
