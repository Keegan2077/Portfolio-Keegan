print("HI")
