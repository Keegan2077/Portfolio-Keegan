"Name" = "Jordan"
"Agme" = "18"
Print (f"Hello (Name), + you are (Age) years old.
