import random

score = 0

print("Welcome to the Math Game!")
print("Answer correctly to keep playing.")
print("One wrong answer ends the game.\n")

while True:
    num1 = random.randint(1, 10)
    num2 = random.randint(1, 10)
    operation = random.choice(["+", "-", "*"])

    if operation == "+":
        correct = num1 + num2
    elif operation == "-":
        correct = num1 - num2
    else:
        correct = num1 * num2

    try:
        answer = int(input(f"What is {num1} {operation} {num2}? "))
    except ValueError:
        print("\nInvalid input.")
        print(f"Game over! Final score: {score}")
        break

    if answer != correct:
        print(f"\nWrong! The correct answer was {correct}.")
        print(f"Game over! Final score: {score}")
        break

    score += 1
    print(f"Correct! Score: {score}\n")
