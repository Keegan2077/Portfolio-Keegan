#this program ask for age
name = "kyle"

print (f"hello {name}!")
