password = ""
while password != "python123":
    password = input("Enter the password: ")
print("Access granted!")
