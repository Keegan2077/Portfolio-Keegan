import random

x = random.randrange(1,10)

guess = int(input("guess a number btween 1 and 10: "))

while guess != x:
    print("too low! try again. \n")
    guess = int(input("guess a number between 1 and 10: "))

print("congratulations")
