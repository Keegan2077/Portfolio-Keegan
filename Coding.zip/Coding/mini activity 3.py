# this program ask for the price of an item

price = 2.00 # in dollers
tax = 0.75 # in cent

print(f"the cost of the item is {price} plus {tax} in tax, the cost of the total cost is {price + tax}.")
