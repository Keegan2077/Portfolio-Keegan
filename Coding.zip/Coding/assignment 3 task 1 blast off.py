
number1 =int (input ("write a number"))

for x in range(number1, 22, 2):
      print(x)    

print ("Blast off!")
