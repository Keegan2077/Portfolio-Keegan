# Step 1: Ask the user to enter their test score
age = "16"

# Step 2: Check if the score is greater than or equal to 50
if age == "<18":

 print("you are old enough to vote.")

else: age == ">18"

print("you are not old enough to vote.")    
