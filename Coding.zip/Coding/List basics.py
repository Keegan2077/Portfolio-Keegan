temperatures = [18, 21, 19, 23, 20]

for temp in temperatures:
    print(temp)
