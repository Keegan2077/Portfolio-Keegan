"""
===============================================
Assignment [insert number here] 
Student Name: [Insert name here]
Date: [Insert date here]

By typing my name above, I confirm that this is my own work
and I have not plagiarized or copied code from others or AI sources.
===============================================
"""

# =======================================================
# Question 1: Say your name!
# Write a program that displays your name!
# =======================================================
name = "keegan"
print(f"my name is {name}.")
