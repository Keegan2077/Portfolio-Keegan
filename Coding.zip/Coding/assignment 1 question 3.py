number1 = int(input("pick a number"))
number2 = int(input ("pick a number"))
number3 = int(input ("pick a number"))
print (f" your three numbers averaged are (int({number1+number2+number3}/3")
