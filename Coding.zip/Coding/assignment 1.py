name = input("your name")

print (f"hello {name} nice to meet you")
