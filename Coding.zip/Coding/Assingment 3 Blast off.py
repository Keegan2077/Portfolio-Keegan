number1 = int input( ("write a  number")
                     
