num_1 = input("42: ")
num_2 = input("67 )

answer = 42 + 67
