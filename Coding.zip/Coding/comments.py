count = 1
while count <= 5:
    print(f"Count is: {count}")
    count += 1
