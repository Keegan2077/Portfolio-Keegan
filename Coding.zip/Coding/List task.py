foods = ["chicken alfredo", "burgers", "mac n cheese", "sloppy joes", "grilled cheese"]

for food in foods:
    print(food)
