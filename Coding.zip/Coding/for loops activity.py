count = 1
while count <= 17:
    print(f"Count is: {count}")
    count += 2
 count = (input)

