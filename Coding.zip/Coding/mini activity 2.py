# this program calculates the perimeter of a rectangle

length = 7 # length in meters
width = 4 # width in meters

perimeter = length + width

print (f"the perimeter is {perimeter} in meters.")
