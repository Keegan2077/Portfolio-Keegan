#this program ask the cost of pizza with tax
cost of pizza with tax = "7.91"

print "({the cost of pizza with tax})"
