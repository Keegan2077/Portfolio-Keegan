number1 = int(input("pick a number"))
number2 = int(input ("pick a number"))
print (f" your two numbers added together are {number1+number2}")
