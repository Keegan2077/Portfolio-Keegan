If I am hungry, then:
    go to the kitchen.
Else if there was no food in kitchen, then:
    go to the store to buy some
End if


If I get an A in this course, then:
    my parents will be happy
Else if I dont get an A, then:
    my parents will be upset
End if


If I won the lottery, then:
    I will make a bed of money
Else if I do not win, then:
    I go on as normal.
End if
